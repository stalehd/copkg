this file is just a test file for the ZIP file unpacking thing.
it does not contain anything exciting.
